<?php

$path = 'image/download.png';
$type = pathinfo($path, PATHINFO_EXTENSION);
$data = file_get_contents($path);
$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

echo 'Image to Encode = '. $base64;

echo '<br/>';

$img = "<img src='$base64'/>";

print('Getting Back Image = '.$img);

?>